//
//  ViewController.swift
//  airplanegame1
//
//  Created by Abayomi kazeem Sodia.  on 18/12/2018.
//  Copyright © 2018 Abayomi kazeem Sodia. . All rights reserved.
//

import UIKit

protocol subviewDelegate {
    func changeSomething()
}


class ViewController: UIViewController, subviewDelegate {
    
  
    
    func changeSomething() {
       
       
        display.text = "X Position: " + planeimageview.center.x.description
    
    
    }
    

   
    @IBOutlet weak var road: UIImageView!
    
    
    @IBOutlet weak var planeimageview: draggingimageview!
    
    
    @IBOutlet weak var display: UILabel!
    
    
    @IBOutlet weak var RUN: UIButton!
    @IBOutlet weak var bird: UIImageView!
   
    @IBOutlet weak var bird1: UIImageView!
    
    @IBOutlet weak var bird2: UIImageView!
    @IBOutlet weak var bird3: UIImageView!
    @IBOutlet weak var bird4: UIImageView!
    @IBOutlet weak var bird5: UIImageView!
    @IBOutlet weak var finalscore: UILabel!
   
    @IBOutlet weak var tree: UIImageView!
    
    
    
    @IBAction func REPLAY(_ sender: Any) {
        
        finalscore.text = ""
        score = 0;
        Gameisover.isHidden = true
        RUN.isHidden = true
       
        for i in gameplane {
            i.removeFromSuperview()
        }
        
       

        UIView.animate(withDuration: 5, delay: 0.0, options: [UIView.AnimationOptions.repeat, .curveLinear], animations:
            {
                self.bird4.center.x -= self.view.bounds.width
                self.bird5.center.x -= self.view.bounds.width
                
        }, completion: nil
        )
        
      
        
         viewDidLoad()
        
    }
    @IBOutlet weak var cloud: UIImageView!
    
    @IBOutlet weak var cloud2: UIImageView!
    
    
    
    var gameplane: [UIImageView] = []
    var dynamicAnimator: UIDynamicAnimator!
    var collisionBehavior: UICollisionBehavior!
    var gravityBehavior: UIGravityBehavior!
    var dynamicItemBehavior: UIDynamicItemBehavior!
    var dIBehaviour: UIDynamicItemBehavior!
    var gBehaviour: UIGravityBehavior!
    var cBehaviour: UICollisionBehavior!
    var scoreArray: [UIImageView] = []
    var score = 0;
    var timer: Timer!
   let Gameisover = UIImageView(image: nil)
    
 
    let birdsArray = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
  
    
    func changesomething()
    {
        
        
       
    }
    
    let obstacleimage = UIImageView(image: nil)

            override func viewDidLoad() {
            super.viewDidLoad()
              
                
                dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
                dIBehaviour = UIDynamicItemBehavior(items: [])
                cBehaviour = UICollisionBehavior(items: [])
                
                
            
               
               
                
                dynamicItemBehavior = UIDynamicItemBehavior(items: [cloud2])
                self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -15, y: 0), for: cloud2)
                dynamicAnimator.addBehavior(dynamicItemBehavior)
               
              
                var imageArray: [UIImage]!
        imageArray = [UIImage(named: "road1")!,
                      UIImage(named: "road2")!,
                      UIImage(named: "road3")!,
                      UIImage(named: "road4")!,
                      UIImage(named: "road5")!,
                      UIImage(named: "road6")!,
                      UIImage(named: "road7")!,
                      UIImage(named: "road8")!,
                      UIImage(named: "road9")!,
                      UIImage(named: "road10")!,
                      UIImage(named: "road11")!,
                      UIImage(named: "road12")!,
                      UIImage(named: "road13")!,
                      UIImage(named: "road14")!,
                      UIImage(named: "road15")!,
                      UIImage(named: "road16")!,
                      UIImage(named: "road17")!,
                      UIImage(named: "road18")!,
                      UIImage(named: "road19")!]
        
        self.road.image = UIImage.animatedImage(with: imageArray, duration: 0.15)
        
                
                var treeArray: [UIImage]!
                treeArray = [UIImage(named: "tree1")!,
                              UIImage(named: "tree2")!,
                              UIImage(named: "tree3")!,
                              UIImage(named: "tree4")!,
                              UIImage(named: "tree5")!,
                              UIImage(named: "tree6")!,
                              UIImage(named: "tree7")!,
                              UIImage(named: "tree8")!,
                              UIImage(named: "tree9")!,
                              UIImage(named: "tree10")!,
                              UIImage(named: "tree11")!,
                              UIImage(named: "tree12")!,
                              UIImage(named: "tree13")!,
                              UIImage(named: "tree14")!,
                              UIImage(named: "tree15")!,
                              UIImage(named: "tree16")!,
                              UIImage(named: "tree17")!,]
                
                self.tree.image = UIImage.animatedImage(with: treeArray, duration: 0.30)

                var birdArray: [UIImage]!
                birdArray = [UIImage(named: "bird1")!,
                             UIImage(named: "bird2")!,
                             UIImage(named: "bird3")!,
                             UIImage(named: "bird4")!,
                             UIImage(named: "bird5")!,
                             UIImage(named: "bird6")!,
                             UIImage(named: "bird7")!,
                             UIImage(named: "bird8")!,
                             UIImage(named: "bird9")!,
                             UIImage(named: "bird10")!]
                
                
                
                self.bird.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
                self.obstacleimage.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
               
                self.bird1.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
                self.bird3.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
                self.bird2.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
                self.bird4.image = UIImage.animatedImage(with: birdArray, duration: 0.15)
                self.bird5.image = UIImage.animatedImage(with: birdArray, duration: 0.15)

                
                planeimageview.myDelegate = self
               
                self.view.addSubview(planeimageview)
                self.view.bringSubviewToFront(planeimageview)
                
                UIView.animate(withDuration: 5, delay: 0.0, options: [UIView.AnimationOptions.repeat, .curveLinear], animations:
            {
                self.bird1.center.x -= self.view.bounds.width
                self.bird.center.x -= self.view.bounds.width
                
                }, completion: nil
                )
                
                
                for index in 0...19 {
                    let delay = Double(self.birdsArray[index])
                    let when = DispatchTime.now() + delay
                   
                    DispatchQueue.main.asyncAfter(deadline: when){
                        
                        let obstacle = arc4random_uniform(11)
                        let obstacleimage = UIImageView(image: nil)

                        switch obstacle{
                        case 1:
                            
                            self.dynamicItemBehavior = UIDynamicItemBehavior(items: [self.bird2])
                        self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -300, y: 0), for: self.bird2)
                        self.dynamicAnimator.addBehavior(self.dynamicItemBehavior)
                       
                        case 2:
                            
                            self.dynamicItemBehavior = UIDynamicItemBehavior(items: [self.bird3])
                        self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -300, y: 0), for: self.bird3)
                        self.dynamicAnimator.addBehavior(self.dynamicItemBehavior)
                            
                        default:
                          
                            self.dynamicItemBehavior = UIDynamicItemBehavior(items: [self.bird3])
                            self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -300, y: 0), for: self.bird3)
                            self.dynamicAnimator.addBehavior(self.dynamicItemBehavior)
                            
                            
                        }
                        
                        
                        for birds in self.scoreArray{
                            if(self.planeimageview.frame.intersects(birds.frame)){
                                self.score = self.score - 3
                                self.finalscore.text = String(self.score)
                            }
                        }
                        
                        
                        obstacleimage.frame = CGRect( x: 700, y: 100, width: 40, height:65 )
                        
                        let coinview = UIImageView(image: nil)
                        coinview.image = UIImage(named: "coin")
                        coinview.frame = CGRect(x:700, y: 300, width: 40, height: 40)
                       
                        self.view.addSubview(coinview)
                        
                        if(self.planeimageview.frame.intersects(coinview.frame)){
                            self.score = self.score + 3
                            self.finalscore.text = String(self.score)
                        }
                        
                        
                        let coinview2 = UIImageView(image: nil)
                        coinview2.image = UIImage(named: "coin")
                        coinview2.frame = CGRect(x:700, y: 50, width: 40, height: 40)
                        
                        self.view.addSubview(coinview2)
                        
                        
                        self.bird2.frame = CGRect(x: 700, y: 200, width: 40, height: 65)
                        self.view.addSubview(self.bird2)
                        
                        self.bird3.frame = CGRect(x: 700, y: 100, width: 40, height: 65)
                        self.view.addSubview(self.bird3)
                       
                        self.view.addSubview(obstacleimage)
                        self.view.bringSubviewToFront(obstacleimage)
                        self.view.bringSubviewToFront(self.bird1)
                        
                        self.dIBehaviour.addItem(obstacleimage)
                        self.dIBehaviour.addLinearVelocity(CGPoint(x:-300, y:0),for: obstacleimage)
                        self.cBehaviour.addItem(self.bird3)
                        
                        
                        
                     
                        
                        self.dynamicItemBehavior = UIDynamicItemBehavior(items: [coinview])
                        self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -300, y: 0), for: coinview)
                        self.dynamicAnimator.addBehavior(self.dynamicItemBehavior)
                        
                        self.dynamicItemBehavior = UIDynamicItemBehavior(items: [coinview2])
                        self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -300, y: 0), for: coinview2)
                        self.dynamicAnimator.addBehavior(self.dynamicItemBehavior)
                        
                        
                        self.scoreArray.append((obstacleimage))
                        self.score -= 3
                        self.finalscore.text = String(self.score)
                        
                    }
                }
                
                dynamicAnimator.addBehavior(dIBehaviour)
                cBehaviour = UICollisionBehavior(items:[])
                cBehaviour.translatesReferenceBoundsIntoBoundary = false
                dynamicAnimator.addBehavior(cBehaviour)
                
                cBehaviour.removeAllBoundaries()
                cBehaviour.addBoundary(withIdentifier: "plane1" as NSCopying, for: UIBezierPath(rect: planeimageview.frame))

                
                let end = DispatchTime.now() + 20
                DispatchQueue.main.asyncAfter(deadline: end) {
                    
                    self.Gameisover.isHidden = false
                    self.RUN.isHidden = false
                    self.Gameisover.image = UIImage (named: "game_over")
                    self.Gameisover.frame = UIScreen.main.bounds
                    self.view.addSubview(self.Gameisover)
                    self.view.bringSubviewToFront(self.Gameisover)
                    self.view.bringSubviewToFront(self.RUN)
                 
                    
                   
                }
                
    
                
    }
    
}

